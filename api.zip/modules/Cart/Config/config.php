<?php

return [
    'name' => 'Cart'
];
