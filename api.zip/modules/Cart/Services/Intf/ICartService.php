<?php

namespace Modules\Cart\Services\Intf;

interface ICartService
{
    public function search($userId);
}