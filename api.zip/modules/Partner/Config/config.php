<?php

return [
    'name' => 'Partner'
];
