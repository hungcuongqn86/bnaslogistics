<?php

namespace Modules\Partner\Services\Intf;

interface IPartnerService
{
    public function search($filter);
}