<?php

return [
    'name' => 'Common'
];
