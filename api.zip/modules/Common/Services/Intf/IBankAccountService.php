<?php

namespace Modules\Common\Services\Intf;

interface IBankAccountService
{
    public function search($filter);
}