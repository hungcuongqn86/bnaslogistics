<?php

namespace Modules\Common\Services\Intf;
interface ICommonService
{
    public function getAll();

}