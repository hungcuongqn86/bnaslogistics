<?php

namespace Modules\Common\Services\Intf;

interface ITransactionService
{
    public function search($filter);
}