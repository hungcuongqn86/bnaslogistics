<?php

namespace Modules\Common\Services\Intf;

interface IRoleService
{
    public function search($filter);
}