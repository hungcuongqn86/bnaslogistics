<?php

namespace Modules\Common\Services\Intf;

interface IMediaService
{
    public function search($filter);
}