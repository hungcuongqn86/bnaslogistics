<?php

namespace Modules\Common\Services\Intf;

interface IVersionService
{
    public function search($filter);
}