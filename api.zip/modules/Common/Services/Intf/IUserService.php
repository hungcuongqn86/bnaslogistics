<?php

namespace Modules\Common\Services\Intf;

interface IUserService
{
    public function search($filter);
}