<?php

namespace Modules\Common\Services\Intf;

interface ISettingService
{
    public function search($filter);
}