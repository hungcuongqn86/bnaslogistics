<?php

return [
    'name' => 'Shop'
];
