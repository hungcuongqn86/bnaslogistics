<?php

namespace Modules\Shop\Services\Intf;

interface IShopService
{
    public function search($filter);
}