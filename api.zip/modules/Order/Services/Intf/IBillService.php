<?php

namespace Modules\Order\Services\Intf;

interface IBillService
{
    public function search($filter);
}