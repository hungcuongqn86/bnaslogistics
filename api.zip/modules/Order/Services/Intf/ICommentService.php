<?php

namespace Modules\Order\Services\Intf;

interface ICommentService
{
    public function search($filter);
}