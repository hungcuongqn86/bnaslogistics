<?php

namespace Modules\Order\Services\Intf;

interface IComplainProductService
{
    public function search($filter);
}