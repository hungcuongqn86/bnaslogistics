<?php

namespace Modules\Order\Services\Intf;

interface IComplainService
{
    public function search($filter);
}