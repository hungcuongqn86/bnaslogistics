<?php

namespace Modules\Order\Services\Intf;

interface IOrderService
{
    public function search($filter);
}