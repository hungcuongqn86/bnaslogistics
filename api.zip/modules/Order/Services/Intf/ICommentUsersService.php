<?php

namespace Modules\Order\Services\Intf;

interface ICommentUsersService
{
    public function search($filter);
}