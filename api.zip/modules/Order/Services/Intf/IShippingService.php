<?php

namespace Modules\Order\Services\Intf;

interface IShippingService
{
    public function search($filter);
}