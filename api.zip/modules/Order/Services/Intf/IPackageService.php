<?php

namespace Modules\Order\Services\Intf;

interface IPackageService
{
    public function search($filter);
}