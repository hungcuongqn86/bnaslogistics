<?php

namespace Modules\Order\Services\Intf;

interface IHistoryService
{
    public function search($filter);
}