<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Cart\\Providers\\CartServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Cart\\Providers\\CartServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);